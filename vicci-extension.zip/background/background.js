// Function to initialize VICCI
function initVICCI() {
  chrome.commands.onCommand.addListener((command) => {
    console.log('VICCI Background Service: Received command:', command);
    if (command === "activate-vicci") {
      console.log('VICCI Background Service: Activating VICCI');
      chrome.tts.speak("VICCI activated. How can I assist you?", {
        onEvent: function(event) {
          console.log('VICCI Background Service: TTS event:', event.type);
        }
      });
    } else if (command === "describe-page") {
      console.log('VICCI Background Service: Describing page');
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, { action: "describePage" });
      });
    }
  });

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('VICCI Background Service: Received message:', request);
    if (request.action === "speak") {
      console.log('VICCI Background Service: Speaking text:', request.text);
      chrome.tts.speak(request.text, {
        rate: 1.0,
        pitch: 1.0,
        onEvent: function(event) {
          console.log('VICCI Background Service: TTS event:', event.type);
          if (event.type === 'end') {
            sendResponse({ status: "completed" });
          }
        }
      });
      return true;  // Indicates we wish to send a response asynchronously
    }
  });

  console.log('VICCI Background Service: Initialization complete');
}

chrome.runtime.onInstalled.addListener(() => {
  console.log('VICCI Background Service: Extension installed');
  initVICCI();
});

// Call initVICCI immediately as well, in case the service worker is already running
initVICCI();

// Add this at the end of your background.js file
self.addEventListener('fetch', function(event) {
  // This empty fetch listener is sometimes needed to keep the service worker alive
});
