console.log('VICCI Content Script: Initializing...');

let isVicciActive = false;

function activateVicci() {
  console.log('VICCI Content Script: Activating VICCI');
  isVicciActive = true;
  speakFeedback(window.VICCI.config.initialMessage);
}

function deactivateVicci() {
  console.log('VICCI Content Script: Deactivating VICCI');
  isVicciActive = false;
  speakFeedback("VICCI deactivated.");
}

function speakFeedback(text) {
  console.log('VICCI Content Script: Speaking feedback:', text);
  chrome.runtime.sendMessage({ action: "speak", text: text }, (response) => {
    console.log('VICCI Content Script: TTS response:', response);
  });
}

document.addEventListener('keydown', (event) => {
  console.log('VICCI Content Script: Keydown event:', event.key);
  
  if (event.altKey && event.shiftKey && event.key === 'V') {
    console.log('VICCI Content Script: Activation shortcut detected');
    if (isVicciActive) {
      deactivateVicci();
    } else {
      activateVicci();
    }
  }

  if (isVicciActive) {
    console.log('VICCI Content Script: VICCI is active, checking for commands');
    switch(event.key.toLowerCase()) {
      case 'h':
        console.log('VICCI Content Script: Help command detected');
        window.VICCI.actions.help();
        break;
      case 'p':
        console.log('VICCI Content Script: Describe page command detected');
        window.VICCI.describePage();
        break;
      // Add more command handlers here
    }
  } else {
    console.log('VICCI Content Script: VICCI is not active');
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('VICCI Content Script: Received message', request);
  
  if (request.action === "activateVicci") {
    activateVicci();
  } else if (request.action === "describePage") {
    window.VICCI.describePage();
  }
});

console.log('VICCI Content Script: Initialization complete');
